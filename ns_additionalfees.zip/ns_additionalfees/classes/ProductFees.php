<?php

class ProductFees extends ObjectModel
{
	/** @var integer */
	public $id_fees;
		
	/** @var integer */
	public $id_product;
	
	/** @var integer */
	public $washing_fees;
	
	public $washing_fees_name;
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'ns_product_fees',
        'primary' => 'id_fees',
        'multilang' => FALSE,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
            'washing_fees' => array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat', 'required' => TRUE),
			'washing_fees_name' => array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => TRUE),
        ),
    );
	
    public static function loadByIdProduct($id_product){
        $result = Db::getInstance()->getRow('
            SELECT  *   
            FROM `'._DB_PREFIX_.'ns_product_fees` sample
            WHERE sample.`id_product` = '.(int)$id_product
        );
		
		if(isset($result['id_fees']) && isset($result['id_product'])){
        
        return new ProductFees($result['id_fees']);
		
		}
		
				
		
		}
		
		
		
		
		
    
}

