<?php

if (!defined('_PS_VERSION_'))
  exit;
 
use PrestaShop\PrestaShop\Adapter\SymfonyContainer;
 
require_once(dirname(__FILE__) . '/classes/ProductFees.php'); 
  
  class ns_additionalfees extends Module
  
  {
   
  public function __construct()
  {
    $this->name = 'ns_additionalfees';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'NdiagaSoft';
    $this->need_instance = 0;
	$this->secure_key = Tools::encrypt($this->name);
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    $this->bootstrap = true;
	
 
    parent::__construct();
 
    $this->displayName = $this->l('Additional Fees On cart');
    $this->description = $this->l('Add additional Fees On Price during Shopping cart');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    
  }
    
	  public function install()
	{
	  if (Shop::isFeatureActive())
		Shop::setContext(Shop::CONTEXT_ALL);
	
	$sql = array();
	
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_product_fees` (
                  `id_fees` int(10) unsigned NOT NULL AUTO_INCREMENT,
                  `id_product` INT( 11 ) UNSIGNED NOT NULL,
                  `washing_fees` FLOAT NOT NULL,
				  `washing_fees_name` TEXT NOT NULL,
                  PRIMARY KEY (`id_fees`),
                  UNIQUE  `NS_FEES_UNIQ` (  `id_product` )
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
	 
	  if (!parent::install() ||
		!$this->registerHook('leftColumn') ||
		!$this->registerHook('header') ||
		!$this->registerHook('DisplayFooterProduct')||
        !$this->registerHook('DisplayshoppingCart')||	    
		!$this->registerHook('displayReassurance') ||
        !$this->registerHook('displayAfterProductThumbs') ||
        !$this->registerHook('displayProductAdditionalInfo') ||
		!$this->registerHook('OrderConfirmation')||
		!$this->registerHook('adminOrder')||	
		!$this->runSql($sql) ||
		!$this->registerHook('displayAdminProductsExtra') ||
        !$this->registerHook('actionProductUpdate') ||        
		!$this->registerHook('shoppingCart')
		
	  )
		return false; 		
		
	  return true;
	}

       public function uninstall()
    {
        $sql = array();
	
        //$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_product_fees`';
		
		if (!parent::uninstall()  || 
            !$this->runSql($sql) 		
		
            )
                return false;       
           return true;
    }
	
	public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        
        return TRUE;
    }
  
        public function getContent()
    {
           $output = null;       
		   
		   if (Tools::isSubmit('ViewAssignData')  || Tools::isSubmit('SubmitSaveSelected')  )
		{
			$id_product=(int)Tools::getValue('id_product');
			
			if(Tools::isSubmit('SubmitSaveSelected')){
		            $output.= $this->assignData($id_product);	  
              }	
			
			$output.=$this->displaySelected($id_product);
	    }
		
		else {
	       $output .= $this->displayConfirmation($this->l('No Settings  needed'));	
		}
	  
            return $output;
    }



      public  function assignData($id_product){	  
  
     $message='';
  
      if(Tools::isSubmit('SubmitSaveSelected') &&  !empty($id_product)){	      
        
            $sampleObj =new ProductFees();  
             		   
			$sampleObj->washing_fees = Tools::getValue('washing_fees');
		    $sampleObj->washing_fees_name = Tools::getValue('washing_fees_name');
            $sampleObj->id_product = $id_product;		
            $sampleObj->add();
			$message=$this->displayConfirmation($this->l('Fees  added Successfully.'));
      
		
      }
	  
	  
	  return  $message;
	  
  }	
  
  	public function displaySelected($id_product)
  {		
		
	
		$base_dir_nka=Tools::getHttpHost(true).__PS_BASE_URI__; 
		
		$token=Tools::getAdminTokenLite('AdminModules');
		$nka_display_link='index.php?controller=AdminModules&configure=ns_additionalfees&id_product='.$id_product.'&ViewAssignData&token='.$token;
		$result_submit_link=$nka_display_link;
		
		
		$product=new Product($id_product);
		
		$full_url=_PS_ADMIN_DIR_;
		$pattern = "/[-\s:]/";
		$full_url_one=preg_split($pattern, $full_url);
		$full_url_two=$full_url_one[1];
		$full_url_tree=explode('\\', $full_url_two);
		$ps_admin_dir=array_pop($full_url_tree);		
		
		
		$sfContainer = SymfonyContainer::getInstance();
		$sfRouter = $sfContainer->get('router');
		$product_link_back=$sfRouter->generate(
                        'admin_product_form',
                        ['id' => $id_product]
                    );
		 
		
		$this->context->smarty->assign(array(			
		'nka_display_link' =>$nka_display_link,
		'result_submit_link'=>$result_submit_link,        
	    'id_product'=>$id_product,
	    'product'=>$product,
        'token'=>$token,
        'base_dir_nka'=>$base_dir_nka,
	    'product_link_front'=>$this->context->link->getProductLink($product),		
		'id_lang'=>$this->context->language->id,
		'product_link_back'=>$product_link_back,
		'ps_admin_dir'=>$ps_admin_dir ,
       	  
        
	));
	
	
	  return $this->display(__FILE__, 'display_selected.tpl');
   }
	
	
   
   
	
	 public function hookDisplayAdminProductsExtra($params) {
        $id_product =_PS_VERSION_ < '1.7' ? (int) Tools::getValue('id_product') : (int) $params['id_product'];
        $sampleObj = ProductFees::loadByIdProduct($id_product);
		
        if(!empty($sampleObj) && isset($sampleObj->id)){
            $this->context->smarty->assign(array(
                'washing_fees' => $sampleObj->washing_fees,
				'washing_fees_name' => $sampleObj->washing_fees_name,
				'sampleObj'=>$sampleObj,
            ));
        }
		
		
		$module_path=_PS_MODULE_DIR_.$this->name;
		
		 $this->context->smarty->assign(array(			
				'id_product'=>$id_product,
				'token'=>Tools::getAdminTokenLite('AdminModules'),
                'product_token'=>Tools::getAdminTokenLite('AdminProducts'),				
				
            ));
        
        return $this->display(__FILE__, 'views/templates/admin/sample.tpl');
    }
    
    public function hookActionProductUpdate($params) {
        $id_product =_PS_VERSION_ < '1.7' ? (int) Tools::getValue('id_product') : (int) $params['id_product'];
           $sampleObj = ProductFees::loadByIdProduct($id_product);  
             		   
			$sampleObj->washing_fees = Tools::getValue('washing_fees');
		    $sampleObj->washing_fees_name = Tools::getValue('washing_fees_name');
            $sampleObj->id_product = $id_product;		
		
        if(!empty($sampleObj) && isset($sampleObj->id)){			
            $sampleObj->update();
        } 
		
		
    }	
	 
   public function hookDisplayAfterProductThumbs($params)
	{                  
	     
		 $id_product =(int)Tools::getValue('id_product');
	   
       $sampleObj = ProductFees::loadByIdProduct($id_product);
	   $this->context->smarty->assign('sampleObj' , $sampleObj);
	   $this->context->smarty->assign('currency' , $this->context->currency);
	   
	   return $this->display(__FILE__, 'footer_product.tpl');
        
    } 	 	
    
	
	public function hookshoppingCart($params){   
   
    $context=Context::getContext();
	$id_cart=$context->cookie->id_cart;           
	
	 $this->context->smarty->assign('total_fees' ,$this->totalCartFees($params));
	 $this->context->smarty->assign('currency' , $this->context->currency);
	 
	 $products = $params['cart']->getProducts(true);
	 
     $this->context->smarty->assign('products' ,$products );	 	 
  
     return $this->display(__FILE__, 'hook_shopping_cart.tpl');
   
   
   }
   
   
   public   function getProductFees($id_product)
	{
		$sample=ProductFees::loadByIdProduct($id_product);

		return $sample;
	}  
  


  public function totalCartFees(){ 
 
 
 $products = $this->context->cart->getProducts(true);
	$TotalFees = 0;
		foreach ($products as $product){
			$ObjFees=$this->getProductFees($product['id_product']);
			if(isset($ObjFees->washing_fees)){
			$TotalFees += (int)$product['cart_quantity']*$ObjFees->washing_fees;
		     }
		}
			
			return  $TotalFees;
 
 }    
	
	
  public function totalCartFeesOrder($params){ 
 
          $id_order=(int)Tools::getValue('id_order');
		 $order=new Order($id_order);	  
	     $id_cart=$order->id_cart;
		 $cart=new Cart($id_cart);
 
   $products =$cart->getProducts(true);
	$TotalFees = 0;
		foreach ($products as $product){
			$ObjFees=$this->getProductFees($product['id_product']);
			$TotalFees += (int)$product['cart_quantity']*$ObjFees->washing_fees;
		}
			
			return  $TotalFees;
 
 }    	
	
	 public function  hookDisplayOrderConfirmation($params) 
   {
         $id_order=(int)Tools::getValue('id_order');
		 $id_cart=(int)Tools::getValue('id_cart');
		 $cart=new Cart($id_cart);
		 
          $this->context->smarty->assign('total_fees' ,$this->totalCartFeesOrder($params));
	 $this->context->smarty->assign('currency' , $this->context->currency);
	 
	 $products = $cart->getProducts(true);
	 
     $this->context->smarty->assign('products' ,$products);	 	 
  
     return $this->display(__FILE__, 'hook_shopping_cart.tpl');
   }
   
   
    public function hookAdminOrder($params)
	{
	  
	  
	  $id_order=(int)Tools::getValue('id_order');
	  $order=new Order($id_order);
	  $id_customer=$order->id_customer;
	  $id_cart=$order->id_cart;
	  $cart=new Cart($id_cart);
	  $products = $cart->getProducts(true);
	  
      $this->context->smarty->assign(
      array(		  	  
          'update_token'=>Tools::getAdminTokenLite('AdminModules'),
          'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
		  'products'=>$products,
		  'total_fees'=>$this->totalCartFeesOrder($params),
		  'currency'=>$this->context->currency,
                    
            )
            );   


     return $this->display(__FILE__, 'order_details.tpl'); 	  
	 
	
	}
	
	
	
   
  }