<?php
if (!defined('_PS_VERSION_'))
 exit; 

class additionalfeesdisplayModuleFrontController extends ModuleFrontController
{
  public function initContent()
  {
   
    parent::initContent();
	
	AdditionalFees::enableFees();
	$id_cart=(int)Tools::getValue('id_cart');
	$theCart = new Cart($id_cart);    
	// Set currency
		if ((int)$theCart->id_currency && (int)$theCart->id_currency != $this->context->currency->id)
			$currency = new Currency((int)$theCart->id_currency);
		else
			$currency = $this->context->currency;
	$order_total=Tools::displayPrice($theCart->getOrderTotal(false, Cart::ONLY_PRODUCTS), $currency);
	$total_fees=Tools::displayPrice(AdditionalFees::getTotalFees(), $currency);
	$order_total_plus_fees=$theCart->getOrderTotal(false, Cart::ONLY_PRODUCTS)+ AdditionalFees::getTotalFees();
	
	$this->context->smarty->assign(array(
    'total' =>$order_total,   
    'another_smarty_tag' => $this->nka_filter(),
	'total_fees'=>$total_fees,
	'order_total_plus_fees'=>Tools::displayPrice($order_total_plus_fees,$currency)
	
    
));
    $this->setTemplate('display.tpl');
  }
  
  
  
  
  
  
  
  
  function nka_filter(){
  
  $sql = 'SELECT * FROM '._DB_PREFIX_.'washing_fees';
   if ($results = Db::getInstance()->ExecuteS($sql))
    foreach ($results as $row)
        echo $row['id_fees'].' :: '.$row['id_cart'].'::'.$row['active'].'<br />';  
  
 }
  
  
   
  
  
  
  
  
  
  
 
}